package net.mcreator.enhancing.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class ScytheAttackProcedure
{
	private static final float RADIUS = 6f;
	private static final float KNOCKBACK = 1f;
	private static final float VERTICAL_KNOCKBACK = 0.25f;
	private static final float MIN_DAMAGE = 5f;
	private static final float MAX_DAMAGE = 7.5f;

	public static Vec3 normalize(Vec3 _input)
	{
		double _magnitude = (double)Mth.sqrt((float)_input.x * (float)_input.x + (float)_input.y * (float)_input.y + (float)_input.z * (float)_input.z);
		double _x = (_input.x == 0) ? 0 : _input.x / _magnitude;
		double _y = (_input.y == 0) ? 0 : _input.y / _magnitude;
		double _z = (_input.z == 0) ? 0 : _input.z / _magnitude;
		
		return new Vec3(_x, _y, _z);
	}

	public static void execute(LevelAccessor _world, double _x, double _y, double _z, Entity _hitEnemy, Entity _playerEntity)
	{
		if (_hitEnemy == null || _playerEntity == null)
		{
			return;
		}
	
		final Vec3 _center = new Vec3(((_hitEnemy.getX() + _x) / 2), ((_hitEnemy.getY() + _y) / 2), ((_hitEnemy.getZ() + _z) / 2));
		List<Entity> _entfound = _world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(RADIUS / 2d), e -> true).stream()
					.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			
		for (Entity _enemy : _entfound)
		{
			if (!(_playerEntity == _enemy) && (_playerEntity instanceof Player _player))
			{
				_enemy.hurt(DamageSource.playerAttack(_player), Mth.nextFloat(RandomSource.create(), MIN_DAMAGE, MAX_DAMAGE));

				Vec3 _enemyPos = new Vec3(_enemy.getX(), _enemy.getY(), _enemy.getZ());
				Vec3 _playerPos = new Vec3(_x, _y, _z);
				Vec3 _directionFromEnemyToPlayer = normalize(new Vec3(_playerPos.x - _enemyPos.x, _playerPos.y - _enemyPos.y, _playerPos.z - _enemyPos.z));
				
				_enemy.setDeltaMovement(
					new Vec3(
						(_enemy.getDeltaMovement().x() + -_directionFromEnemyToPlayer.x * KNOCKBACK),
						(_enemy.getDeltaMovement().y() + -_directionFromEnemyToPlayer.y * VERTICAL_KNOCKBACK),
						(_enemy.getDeltaMovement().z() + -_directionFromEnemyToPlayer.z * KNOCKBACK)
					)
				);
			}
		}
	}
}
