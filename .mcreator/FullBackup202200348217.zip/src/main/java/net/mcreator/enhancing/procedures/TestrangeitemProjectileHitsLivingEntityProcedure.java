package net.mcreator.enhancing.procedures;

public class TestrangeitemProjectileHitsLivingEntityProcedure {
	public static void execute() {
	}
}
