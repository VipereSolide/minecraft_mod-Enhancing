
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.enhancing.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.enhancing.item.TestrangeitemItem;
import net.mcreator.enhancing.item.ScytheItem;
import net.mcreator.enhancing.item.QuiverItem;
import net.mcreator.enhancing.item.MysticalCrossbowItem;
import net.mcreator.enhancing.item.EnchantingRuneItem;
import net.mcreator.enhancing.item.EdlerBowItem;
import net.mcreator.enhancing.item.AmethystDaggerItem;
import net.mcreator.enhancing.EnhancingMod;

public class EnhancingModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EnhancingMod.MODID);
	public static final RegistryObject<Item> ENCHANTING_RUNE = REGISTRY.register("enchanting_rune", () -> new EnchantingRuneItem());
	public static final RegistryObject<Item> QUIVER = REGISTRY.register("quiver", () -> new QuiverItem());
	public static final RegistryObject<Item> SCYTHE = REGISTRY.register("scythe", () -> new ScytheItem());
	public static final RegistryObject<Item> AMETHYST_DAGGER = REGISTRY.register("amethyst_dagger", () -> new AmethystDaggerItem());
	public static final RegistryObject<Item> EDLER_BOW = REGISTRY.register("edler_bow", () -> new EdlerBowItem());
	public static final RegistryObject<Item> MYSTICAL_CROSSBOW = REGISTRY.register("mystical_crossbow", () -> new MysticalCrossbowItem());
	public static final RegistryObject<Item> TESTRANGEITEM = REGISTRY.register("testrangeitem", () -> new TestrangeitemItem());
}
